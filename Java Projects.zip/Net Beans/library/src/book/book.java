/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package book;

/**
 *
 * @author 193037
 */
public class book {
   
    String name;
    boolean status;
    
    public book(String name2)
    {name = name2;
    status = true;}
    
    public void borrowed()
    {status = false;}
    
    public void returned()
    {status = true;}
    
    public boolean status()
    {return(status);}
    
    public String name()
    {return(name);}
}