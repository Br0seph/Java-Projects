/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;

/**
 *
 * @author 193037
 */
import book.book;
import java.util.*;
public class Library {

    /**
     * @param args the command line arguments
     */
      static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    static String red = "\u001B[31m";
     static String blue = "\u001B[34m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        String opt;
        
        System.out.println("Welcome to the library book manager.");
        System.out.println("You have 5 books in the libray.");
        System.out.println("Now name them.");
        
        System.out.print("Book 1: ");
        book book1 = new book (doabarrelroll.nextLine());
        System.out.print("Book 2: ");
        book book2 = new book (doabarrelroll.nextLine());
        System.out.print("Book 3: ");
        book book3 = new book (doabarrelroll.nextLine());
         System.out.print("Book 4: ");
        book book4 = new book (doabarrelroll.nextLine());
        System.out.print("Book 5: ");
        book book5 = new book (doabarrelroll.nextLine());
        book catalog[] = {book1, book2, book3, book4, book5};
        
        System.out.println("All books have been registered it is time to open the library.");
        
        do{
        System.out.println(blue + "'Display' Catalog." + black);
        System.out.println(blue + "'Rent' Book." + black);
        System.out.println(blue + "'Return' Book." + black);
        System.out.println(blue + "Display 'Available' Books." + black);
        System.out.println(blue + "Display 'Nonpresent' Books." + black);
        System.out.println(blue + "'Close' Library." + black);
        opt = doabarrelroll.next();
        
        if (opt.equalsIgnoreCase("display"))
        {Display(catalog);
        opt = "null";}
        else if (opt.equalsIgnoreCase("rent"))
        {Rent(catalog);
        opt = "null";}
        else if (opt.equalsIgnoreCase("return"))
        {}
        else if (opt.equalsIgnoreCase("available"))
        {}
        else if (opt.equalsIgnoreCase("nonpresent"))
        {}
        else if (opt.equalsIgnoreCase("close"))
        {}
        else
        {System.err.println("ERROR.  ONLY REGISTERED COMMANDS ALLOWED.");
        opt = "null";}}
        while(opt.equalsIgnoreCase("null"));
    }
    
    public static void Display(book catalog[])
    {for (int bogus = 0; bogus < catalog.length; bogus++)
    {System.out.print(catalog[bogus].name());
    System.out.println(", In Stock: " + red + catalog[bogus].status() + black);}}
    
    public static void Rent(book catalog[])
    {Scanner doabarrelroll = new Scanner (System.in);
    int bnum;
    boolean bool;
    do{
    System.out.print("What book number do you want to take out (they correspond to the order you entered them in): ");
    do{ bnum = doabarrelroll.nextInt();
    if (( bnum < 1)||(bnum > 5))
    {System.err.println("ERROR.  ONLY NUMBERS 1-5 ARE ALLOWED.");}
    else
    {}}
    while((bnum < 1)||(bnum > 5));
    
    bool = catalog[bnum-1].status();
    if (bool = true)
    {catalog[bnum - 1].borrowed();
    System.out.println(catalog[bnum-1].name() + " is marked as " + red + "rented." + black);}
    else
    {System.out.println(catalog[bnum-1].name() + " is already " + red + "rented" + black + ".  Choose another book.");
    bool = false;}}
    while(bool = false);}
}