/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package age;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Age {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner age = new Scanner (System.in);
        
        System.out.println("Did you birthday already pass this year (type true or false)?");
        
        boolean age3 = age.nextBoolean();
        
        if (age3 == true)
        {System.out.println("Type your age and press the enter key");
        int age2 = age.nextInt();
        int year = 2017 - age2;
        if (age2 >= 65)
        {System.out.println("You are a senior citizen");}
        else if (age2 >= 18)
        {System.out.println("You are an adult");}
        if (age2 == 0)
        {System.out.println("Happy Birthday!");}
        System.out.print("Your age: ");
        System.out.println(age2);
        System.out.print("Your birth year: ");
        System.out.println(year);}
        
       if (age3 == false)
       {System.out.println("Type your age and press the enter key");
        int age2 = age.nextInt();
        int year = 2016 - age2;
        if (age2 >= 65)
        {System.out.println("You are a senior citizen");}
        else if (age2 >= 18)
        {System.out.println("You are an adult");}
        if (age2 == 0)
        {System.out.println("Happy Birthday!");}
        System.out.print("Your age: ");
        System.out.println(age2);
        System.out.print("Your birth year: ");
        System.out.println(year);}
    }
}