/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pig;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Pig {

    /**
     * @param args the command line arguments
     */
     static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    static String red = "\u001B[31m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        Random rand = new Random();
        int cpu = 0, user, dice, pts;
        String choice;
        
        System.out.println("*Welcome to Pig!*");
        System.out.println();
        do{
        System.out.print(green + "RULES/PLAY/ADVANCED" + black + " (rules for advanced game): ");
        choice = doabarrelroll.next();
        System.out.println();
        choice = rules(choice);
        System.out.println();}
        while (choice.equalsIgnoreCase("rules")||choice.equalsIgnoreCase("advanced"));
        
        System.out.println("CPU's turn.");
        System.out.println("CPU rolled a ");
        for (int bogus = 0; bogus < 3; bogus++)
        {System.out.println(dice = roll());
        cpu = dice + cpu;}
        
        do{
        System.out.print("Hit the space key when you are ready.");
        choice = doabarrelroll.next();
        if (choice.equals(" "))
        {System.out.println("Get ready!");}
        else
        {choice = "no";}}
        while (choice.equalsIgnoreCase("no"));
        
        dice = roll();
        if (dice == 0)
        {System.out.println("You rolled a 0.  You lose all the points gained in this round.");
        pts = 0;}
        else
        {choice();}
    }
    
    public static String rules(String choice)
    {if (choice.equalsIgnoreCase("rules"))
    {System.out.println("The object of the game is to be the first to 100 points (pts).");
    System.out.println("The CPU rolls 3 die first, and the sum of the die are added to its score.");
    System.out.println("You now roll the die.");
    System.out.println("If it is a 1, you stop rolling the die and no points are scored.");
    System.out.println("If you roll a 2-6, you can roll again if you want to, but it risks you getting a 1, and then no points will be scored.");
    System.out.println("You can roll as many times as you want as long as you do not get a 1.");
    System.out.println("You win when you get 100pts.");
    System.out.println("Total Points are displayed at the end of each round.");
    System.out.println("You are now ready to play.");
    System.out.println("Navigate to the PLAY menu and choose standard to play.");
    choice = "rules";}
    else if (choice.equalsIgnoreCase("advanced"))
    {System.out.println("Advanced version is still in development.");
    System.out.println("Check back later.");
    choice = "advanced";}
    else if (choice.equalsIgnoreCase("play"))
    {System.out.println("Get ready to play!!!");
    choice = "play";}
    else
    {System.out.println(red + "ERROR.  ONLY REGISTERED ANSWERS ALLOWED.");
    choice = "rules";}
    return(choice);}
    
    public static int roll()
    {Random rand = new Random();
    int dice;
    dice = rand.nextInt(7);
    return(dice);}
    
    public static String choice()
    { Scanner doabarrelroll = new Scanner (System.in);
    String choice;
    do {
    System.out.print("Do you want to roll again: ");
    choice = doabarrelroll.next();
    
    if (choice.equalsIgnoreCase("yes"))
    {}
    else if (choice.equalsIgnoreCase("no"))
    {}
    else
    {System.out.println(red + "ERROR.  ONLY YES AND NO ARE ALLOWED");
    choice = "he";}}
    while (choice.equals("he"));
    return(choice);}
}
