/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package functions;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Functions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Scanner doabarrelroll = new Scanner (System.in);
    
    int array[] = new int[4];
    int bogus;
    
    System.out.print("Value 1: ");
    array[0] = doabarrelroll.nextInt();
    System.out.print("Value 2: ");
    array[1] = doabarrelroll.nextInt();
    System.out.print("Value 3: ");
    array[2] = doabarrelroll.nextInt();
    System.out.print("Value 4: ");
    array[3] = doabarrelroll.nextInt();
    System.out.print("Value 5: ");
    array[4] = doabarrelroll.nextInt();
    
    for (bogus = 0; bogus < array.length; bogus++)
    {System.out.println(array[bogus]);}
    }
}
