/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Array {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Scanner doabarrelroll = new Scanner (System.in);
    
    int array[] = new int[5];
    int bogus, bogus2, bogus3;
    
    for (bogus2 = 0; bogus2 < array.length; bogus2++)
    {bogus3 = bogus2 + 1;
        System.out.print("Value " + bogus3  + ": ");
    array[bogus2] = doabarrelroll.nextInt();}
    
      for (bogus = 0; bogus < array.length; bogus++)
    {System.out.println(array[bogus]);}
      
      System.out.println("REVERSE!!!");
    
    for (bogus = array.length - 1; bogus >= 0; bogus--)
    {System.out.println(array[bogus]);}
    }
}