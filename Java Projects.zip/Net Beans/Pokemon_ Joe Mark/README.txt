Simple Pokemon Fan Game
Make sure to update the file path of the map in the code (must have two slashes whenever a slash is used, or the code will break)
Project made by Joey Yannuzzi and Mark Juenemann
Move with W, A, D, S (press enter after each keypress)
Press E to look at pokemon and their stats
All levels are randomized (except: starter which starts at level 25, Legendary (Pikablu), and Boss)
Walk on yellow patches to avoid battles
Walk on green patches to encounter random wild encounters
Walk on red patches to heal party
Walk on red "A" space to fight boss
Walk on blue "B" space to fight legendary
Walk on blue "T" space to fight trainer with randomized pokemon
Press C for the credits, or beat the boss
Enjoy ;)