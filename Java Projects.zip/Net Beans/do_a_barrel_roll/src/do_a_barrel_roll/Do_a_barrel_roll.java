/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package do_a_barrel_roll;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Do_a_barrel_roll {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    //Scanner
    Scanner doabarrelroll = new Scanner (System.in);
    
    int int1, int2, int3, sum;
    
    char restart;
    
    do
    {do
    {System.out.print("Integer 1: ");
    int1 = doabarrelroll.nextInt();
    System.out.print("Integer 2: ");
    int2 = doabarrelroll.nextInt();
    System.out.print("Integer 3: ");
    int3 = doabarrelroll.nextInt();
    System.out.print("Sum: ");
    sum = int1 +int2 +int3;
    System.out.println(sum);
    System.out.print("Do you want to go again (yes or no): ");
    restart = doabarrelroll.next().charAt(0);}
    while((restart == 'y')||(restart =='Y'));
    
    if ((restart == 'n')||(restart == 'N'))
    {System.out.println("Bye!");}
    
    else
    {System.out.println("You didn't say the magic word!");
    restart = 'y';}}
    while(restart == 'y');
    }
}
