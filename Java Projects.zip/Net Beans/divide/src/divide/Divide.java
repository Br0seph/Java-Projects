/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divide;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Divide {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner doabarrelroll = new Scanner (System.in);
         double num1, num2;
         num1 = doabarrelroll.nextDouble();
         num2 = doabarrelroll.nextDouble();
        System.out.print(divide(num1,num2));
    }
   public static double divide(double num1, double num2)
   {double ans;
   ans = num1/num2;
   return(ans);
   }
}
