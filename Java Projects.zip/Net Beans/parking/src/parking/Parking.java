/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parking;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Parking {

    /**
     */
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        char option;
        int bogus, bogus2, bogus4;
        int money = 0;
        int bogus3 = 0;
        int bogus5 = 0;
        
        System.out.print(ANSI_GREEN + "SET THE AMOUNT OF PARKING SLOTS: " + ANSI_RESET);
        bogus4 = doabarrelroll.nextInt();
        char slots[] = new char[bogus4];
        for (bogus = 0; bogus < slots.length; bogus++)
        {slots[bogus] = 'E';}
        
        do
            
        {bogus5 = 0;
            System.out.print(ANSI_RESET + "Choose an option (display (d), park (p), remove (r), close (c)): ");
        option = doabarrelroll.next().charAt(0);
        
        if ((option == 'd')||(option == 'D'))
        {for (bogus = 0; bogus < slots.length; bogus++)
        {System.out.println(ANSI_GREEN + "[" + slots[bogus] + "]");}
        bogus5 = 1;}
        
        else if ((option == 'p')||(option == 'P'))
        {System.out.print("Which slot do you choose to fill: ");
        bogus2 = doabarrelroll.nextInt();
        if (slots[bogus2 - 1] == 'O')
        {System.err.println("ERROR.  THERE IS A CAR ALREADY IN THAT SLOT");}
        else if (slots[bogus2 - 1] == 'E')
        {slots[bogus2 - 1] = 'O';
        System.out.println(ANSI_GREEN + "PARKING GARAGE UPDATED." + ANSI_RESET);}
        else
        {System.err.println("ERROR.  CANNOT COMPUTE.");
        bogus3 = 1;}
         bogus5 = 1;}
        
        else if ((option == 'r')||(option == 'R'))
        {System.out.print("Which slot do you choose to check out: ");
        bogus2 = doabarrelroll.nextInt();
        if (slots[bogus2 - 1] == 'E')
        {System.err.println("ERROR.  SLOT " + bogus2 + " IS ALREADY EMPTY.");}
        else if (slots[bogus2 - 1] == 'O')
        {slots[bogus2 - 1] = 'E';
        money = money + 25;
        System.out.println(ANSI_GREEN + "PARKING GARAGE UPDATED.  YOU GAINED $25." + ANSI_RESET);}
        else
        {System.err.println("ERROR.  CANNOT COMPUTE.");
        bogus3 = 1;}
         bogus5 = 1;}
        
        else if ((option == 'c')||(option == 'C'))
        {for (bogus = 0; bogus < slots.length; bogus++)
        {if (slots[bogus] == 'O')
        {System.err.print("ERROR.  YOU STILL HAVE A PARKED CAR IN SLOT ");
        System.err.print(bogus + 1);
        System.err.println(".");
            bogus5 = 1;}}}
        
        else
        {System.err.println("ERROR.  ONLY THE REGISTERED CHARACTERS CAN BE USED");}}
        while (bogus5 == 1);
        
        bogus3 = 1;
        if (bogus3 == 1);
        System.out.print(ANSI_GREEN + "YOU EARNED $");
        System.out.println(money + "." + ANSI_RESET);
    }
}