/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class C {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*This program should
        
        *Allow you to type two numbers
        *Calculate the gross pay/ss tax/federal tax/state tax
        *Calculate total amount of money gained/spent on taxes
        *Created by Joey Yannuzzi.  Last edited 2/21/17.
        */
        
        //Startup
         Scanner c = new Scanner (System.in);
        System.out.println("Welcome to the payment calculator.  Enter your rate of pay and hours you work when the promt asks");
        System.out.print("Rate of payment: $");
        
        //Payment input
        double rate = c.nextDouble();
        
        //hours input
        System.out.print("Hours worked: ");
        double hours = c.nextDouble();
        
        //Calculations
        if (hours <= 40)
        {double gross = rate * hours;
        double sstax = gross * .08;
        double ftax = gross * .12;
        double stax = gross * .11;
        System.out.print("Gross pay: $");
        System.out.println(gross);
        System.out.print("SS tax: $");
        System.out.println(sstax);
        System.out.print("Federal tax: $");
        System.out.println(ftax);
        System.out.print("State tax: $");
        System.out.println(stax);
        double tax = sstax + ftax + stax;
        double pay = gross - tax;
        System.out.print("Your total money gain will be $");
        System.out.println(pay);
        System.out.print("Congratulations!  You pay $");
        System.out.print(tax);
        System.out.println(" in taxes!");}
        
        else
        {double over = (hours - 40) * (1.5 * rate);
        double ovr = 40 * rate;
        double gross = ovr + over;
        double sstax = gross * .08;
        double ftax = gross * .12;
        double stax = gross * .11;
        System.out.print("Gross pay: $");
        System.out.println(gross);
        System.out.print("SS tax: $");
        System.out.println(sstax);
        System.out.print("Federal tax: $");
        System.out.println(ftax);
        System.out.print("State tax: $");
        System.out.println(stax);
        double tax = sstax + ftax + stax;
        double pay = gross - tax;
        System.out.print("Your total money gain will be $");
        System.out.println(pay);
        System.out.print("Congratulations!  You pay $");
        System.out.print(tax);
        System.out.println(" in taxes!");}
    }
    //$1.7976931348623158079372897E308
}
