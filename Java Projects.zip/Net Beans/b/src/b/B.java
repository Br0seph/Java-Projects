/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class B {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*This program should
        
        *Allow you to type two numbers
        *Calculate the largest/smallest number (this is not shown by has coding)
        *Calculate wheather one is the multiple of the other
        *Created by Joey Yannuzzi.  Last edited 2/16/17.
        */
        
        //Startup
        
        Scanner b = new Scanner (System.in);
        System.out.println("Welcome to the multiple calculator.  Put in two numbers (integers/decimals are all allowed but not fractions) when the promt asks.");
         System.out.print("Number 1: ");
         
         //First Number input
         double num1 = b.nextDouble();
         
         //Second number input
         System.out.print("Number 2: ");
         double num2 = b.nextDouble();
         
         //Calculations
         if (num1 >= num2)
         {System.out.print(num2);
         double multiple;
         multiple = num1%num2;
         
         if (multiple == 0)
         {System.out.print(" is a multiple of ");
         System.out.println(num1);}
         
         else
         {System.out.print(" is not a multiple of ");
         System.out.println(num1);}}
         
         if (num2 > num1)
         {System.out.print(num1);
         double multiple;
         multiple = num2%num1;
         
         if (multiple == 0)
         {System.out.print(" is a multiple of ");
         System.out.println(num2);}
         
         else
         {System.out.print(" is not a multiple of ");
         System.out.println(num2);}}
    } 
}
