/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Calculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        double num1, num2, add, multi, sub, div, fact, sub2, div2;
        int bogus;
        int bogus2 = 0;
        char restart, operation;
        
        System.out.println("Welcome to the calculator.  Enter a number when the prompt asks.");
        System.out.println("Then enter an operation (multiplication *, addition +, subtraction -, division /, factorial ! NO NEGATIVE FACTORIALS!).");
        
        do
        {fact = 1;
        bogus =1;
        System.out.print("Number 1: ");
        num1 = doabarrelroll.nextDouble();
        System.out.print("Number 2: ");
        num2 = doabarrelroll.nextDouble();
        System.out.print("Operation (enter symbol): ");
        operation = doabarrelroll.next().charAt(0);
        
        if (operation == '+')
        {add = num1 + num2;
        System.out.print(num1);
        System.out.print(" + ");
        System.out.print(num2);
        System.out.print(" = ");
        System.out.println(add);}
        
        else if (operation == '-')
        {sub = num1 - num2;
        sub2 = num2 - num1;
        System.out.print(num1);
        System.out.print(" - ");
        System.out.print(num2);
        System.out.print(" = ");
        System.out.println(sub);
        System.out.print(num2);
        System.out.print(" - ");
        System.out.print(num1);
        System.out.print(" = ");
        System.out.println(sub2);}
        
        else if (operation == '*')
        {multi = num1 * num2;
        System.out.print(num1);
        System.out.print(" × ");
        System.out.print(num2);
        System.out.print(" = ");
        System.out.println(multi);}
        
        else if (operation == '/')
        {if ((num1 == 0)||(num2 == 0))
        {System.err.println("ERROR!  CANNOT DIVIDE BY 0!");}
        else
        {div = num1 / num2;
        div2 = num2 / num1;
        System.out.print(num1);
        System.out.print(" ÷ ");
        System.out.print(num2);
        System.out.print(" = ");
        System.out.println(div);
        System.out.print(num2);
        System.out.print(" ÷ ");
        System.out.print(num1);
        System.out.print(" = ");
        System.out.println(div2);}}
        
        else if (operation =='!')
        
        {if ((num1 >= 0)&&(num2 >= 0))
        {System.out.print(num1);
        for (bogus = 1; bogus < num1; bogus++)
        {System.out.print(" × " + bogus);
        fact = bogus * fact;}
        fact = fact * num1;
        System.out.print(" = ");
        System.out.println(fact);
        System.out.print(num2);
        for (bogus = 1; bogus < num2; bogus++)
        {System.out.print(" × " + bogus);
        fact = bogus * fact;}
        fact = fact * num2;
        System.out.print(" = ");
        System.out.println(fact);}
        
        else
        {System.err.println("ERROR!  NO NEGATIVE FACTORIALS!");}}
        
        System.out.print("Would you like to go again: ");
        restart = doabarrelroll.next().charAt(0);}
        while (( restart == 'y')||(restart == 'Y'));
        
        if ((restart =='n')||(restart == 'N'))
        {System.out.println("Bye!");}
        
        else
        {do
        {System.err.println("ERROR! ONLY YES AND NO WILL WORK!");}
        while (bogus2 == 0);}
    }
}
