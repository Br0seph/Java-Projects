/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dice;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Dice {

    /**
     * @param args the command line arguments
     */
    static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    static String red = "\u001B[31m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner(System.in);
        Random dice = new Random();
        int dice1, dice2, bogus, sum;
        String answer, answer2, answer3;
        double money, bet;
        
        do{
        System.out.print("How much money do you have: ");
        money = doabarrelroll.nextDouble();
        if (money > 0)
        { System.out.println("You walked in with " + green + "$" + money + black + ".");}
        else if (money <= 0)
        {System.err.println("ERROR.  NO NEGATIVE OR ZERO MONEY VALUES");}
        else
        {}}
        while(money <= 0);
        do{
            do{
                System.out.print("How much money do you want to bet: ");
            bet = doabarrelroll.nextDouble();
            if(bet > money)
            {System.err.println("ERROR.  $" + bet + " IS TOO MUCH MONEY.");
            answer3 = "notgood";}
            else if (bet <= 0)
            {answer3 = "notgood";
            System.err.println("ERROR.  NO NEGATIVE OR ZERO DOLLAR BETS.");}
            else
            {answer3 = "good";}}
            while (answer3.equalsIgnoreCase("notgood"));
        do{
        System.out.print("Are you ready to roll the dice (yes/no): ");
        answer = doabarrelroll.next();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println("Okay!");}
        else if (answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("ERROR.  " + answer + " IS NOT VALID ANSWER");
        answer = "no";}}
        while (answer.equalsIgnoreCase("no"));
        
        System.out.println("Ready?");
        System.out.println("ROLL!!!");
        
        dice1 = dice.nextInt(7);
        dice2 = dice.nextInt(7);
        
        System.out.println("Dice 1: " + dice1);
        System.out.println("Dice 2: " + dice2);
        
        System.out.println("If the sum of the dice is even: YOU WIN!!!  If not: too bad.");
        sum = dice1 + dice2;
        
        if ((sum%2) == 1)
        {System.out.println(red + "You lose." + black);
        money = money - bet;}
        else
        {System.out.println(green + "YOU WIN!!!" + black);
        money = money + bet;
        System.out.println("You gained " + green + "$" + bet + black + ".");}
        
        System.out.println("You have " + green +"$" + money + black + " left.");
        
        if (money == 0)
        {System.out.println(red + "You ran out of money." + black);
        System.out.println(red + "You left with no money left.  Spend it wisely.  ( ͡° ͜ʖ ͡°)" + black);
        answer2 = "no";}
        else
        {System.out.print("Do you want to bet again: ");
        answer2 = doabarrelroll.next();
        if (answer2.equalsIgnoreCase("no"))
        {System.out.println("BYE!");
        System.out.println("You left with " + green + "$" + money + black + ".");}
        else if (answer2.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("ERROR.  " + answer2 + " IS NOT VALID ANSWER");}}}
        while (answer2.equalsIgnoreCase("yes"));
    }   
}