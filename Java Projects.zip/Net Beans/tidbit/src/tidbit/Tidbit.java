/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tidbit;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Tidbit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        double payment, opt1p1, opt1p2, opt2p1, opt2p2, opt3, opt3p1, opt3p2, decision;
        int bogus = 1;
        
        System.out.println("Welcome to the TidBit Computer Store credit sevices.  Enter the total payment when the prompt asks.");
        System.out.print("Payment: $");
        payment = doabarrelroll.nextDouble();
        
        System.out.println("Your payment options are below.");
        
        System.out.println("Option 1:");
        System.out.print("Payment 1: $");
        opt1p1 = payment * .15;
        System.out.println(opt1p1);
        System.out.print("Payment 2-5: $");
        opt1p2 = ((payment - opt1p1) / (4)) * 1.05;
        System.out.println(opt1p2);
        
        System.out.println("Option 2:");
        System.out.print("Payment 1: $");
        opt2p1 = payment * .2;
        System.out.println(opt2p1);
        System.out.print("Payment 2-10: $");
        opt2p2 = ((payment - opt2p1) /(9)) * 1.08;
        System.out.println(opt2p2);
        
        System.out.println("Option 3:");
        System.out.print("Payment 1: $");
        opt3p1 = payment * .1;
        System.out.println(opt3p1);
        System.out.print("Payment 2-12: $");
        opt3p2 = ((payment - opt3p1) / (9)) * 1.1;
        System.out.println(opt3p2);
        
        System.out.print("Which option would you like (Select the # 1, 2 or 3): ");
        decision = doabarrelroll.nextDouble();
        
        if (decision == 1)
        {System.out.print("Payment Ticket 1: $");
        System.out.println(opt1p1);
        
        do
        {System.out.print("Payment Ticket $");
        bogus = bogus + 1;
        System.out.print(bogus);
        System.out.print(" : ");
        System.out.println(opt1p2);}
        while (bogus < 5);}
        
        else if (decision == 2)
        {System.out.print("Payment Ticket 1: $");
        System.out.println(opt2p1);
        
        do
        {System.out.print("Payment Ticket $");
        bogus = bogus + 1;
        System.out.print(bogus);
        System.out.print(" : ");
        System.out.println(opt2p2);}
        while (bogus < 10);}
        
        else if (decision == 3)
        {System.out.print("Payment Ticket 1: $");
        System.out.println(opt3p1);
        
        do
        {System.out.print("Payment Ticket $");
        bogus = bogus + 1;
        System.out.print(bogus);
        System.out.print(" : ");
        System.out.println(opt3p2);}
        while (bogus < 12);}
        
        else
        
        {do
        {System.err.print("ERROR!  PAYMENT ");
        System.err.print(decision);
        System.err.println(" IS NOT A REGISTERED PAYMENT PLAN.");}
        while (bogus == 1);}
    }
}
