/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package variables;

/**
 *
 * @author 193037
 */
public class Variables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double a;
        double b;
        double c;
        double d;
        double e;
        double f;
        a = 347;
        b = 958;
        c = a * b;
        d = a + b;
        e = a - b;
        f = a / b;
        System.out.println(a + " x " + b + " = " + c);
        System.out.println(a + " + " + b + " = " + d);
        System.out.println(a + " - " + b + " = " + e);
        System.out.println(a + " ÷ " + b + " = " + f);
    }
}