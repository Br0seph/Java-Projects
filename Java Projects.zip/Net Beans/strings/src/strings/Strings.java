/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strings;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Strings {
    public static String GREEN = "\u001B[32m";
    public static String DEFAULT = "\u001B[0m";
    public static void main(String[] args) {
       
        Scanner doabarrelroll = new Scanner (System.in);
        String type;
        int bogus;
        String sent = "TYPE A SENTENCE: ";
        
        System.out.print(GREEN + sent + DEFAULT);
        type = doabarrelroll.nextLine();
        char letters[] = new char [type.length()];
        
        for (bogus = 0; bogus < letters.length; bogus++)
        {letters[bogus] = type.charAt(bogus);}
        
        for (bogus = letters.length - 1; bogus >= 0; bogus--)
       {System.out.print(letters[bogus]);}
        
        System.out.println(type.substring(0,4));
    }
}