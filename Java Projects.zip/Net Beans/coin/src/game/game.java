/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author 193037
 */
import coin.Coin;
public class game {

    /**
     * @param args the command line arguments
     */
    public static Coin coins[] = new Coin[3];
    public static void main(String[] args) {
        String[] coines = new String[3];
        double[] ammount = new double[3];
        int bogus;
        coines[0] = "Nickel";
        coines[1] = "Dime";
        coines[2] = "Quarter";
        ammount[0] = .05;
        ammount[1] = .1;
        ammount[2] = .25;
        System.out.println("There is one of each coin below:");
        for (bogus = 0; bogus < 3; bogus++)
        {coins[bogus] = new Coin (coines[bogus], ammount[bogus]);
        coins[bogus].print();}
    }
}