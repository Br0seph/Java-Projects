/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coin;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Coin {
    
    String name;
    boolean hot = false;
    double ammount;
    
    public Coin(String name1, double maount)
    {name = name1;
    ammount = maount;}
    
    public String side()
    {Random rand = new Random();
    String side = "tails";
    hot = rand.nextBoolean();
    if (hot = true)
    {side = "heads";}
    return(side);}
    
    public void quarter()
    {}
    
    public void dime()
    {}
    
    public void nickel()
    {}
    
    public void print()
    {System.out.println(name + ", " + ammount);}
}
