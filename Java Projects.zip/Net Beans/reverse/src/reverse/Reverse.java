/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reverse;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Reverse {

    /**
     * @param args the command line arguments
     */
    public static String green = "\u001B[32m";
    public static String black = "\u001B[0m";
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        String type,answer;
        int bogus, bogus2;
        
        do
        {System.out.print(green + "Enter a word: " + black);
        type = doabarrelroll.next();
         char back[] = new char[type.length()];
         bogus2 = 0;
        
        for (bogus = type.length() - 1; bogus >= 0; bogus--)
        {back[bogus2] = type.charAt(bogus);
        bogus2++;}
        
        String reverse = new String(back);
        
        System.out.print(type);
        if (type.equalsIgnoreCase(reverse))
        {System.out.println(" is a palindrome.");}
        else
        {System.out.println(" is not a palindrome");}
        
        System.out.print(green + "Do you want to go again: " + black);
        answer = doabarrelroll.next();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println(green + "Bye");
        System.out.println("(|:-D)" + black);}
        else if(answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("NOT VALID ANSWER");
        answer = "yes";}}
        while((answer.equals("yes"))||(answer.equals("Yes")));
    }
}
