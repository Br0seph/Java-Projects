/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temperature;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Temperature {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        /*Variables*/
        Scanner a = new Scanner (System.in);
        
        System.out.println("Type 'true' for celsius and 'false' for fahrenheit");
        boolean temp;
        
        temp = a.nextBoolean();
        
        if (temp == true)
        {System.out.print("Celsius: ");
         double b = a.nextDouble();
        double c = (b * 1.8) + 32;
        System.out.println(b + "°");
        System.out.print("Fahrenheit: ");
        System.out.println(c + "°");}
        
        else if (temp == false)
        {System.out.print("Fahrenheit: ");
        double d = a.nextDouble();
        double e = (d - 32)/1.8;
        System.out.println(d + "°");
        System.out.print("Celsius: ");
        System.out.println(e + "°");}
    }  
}
