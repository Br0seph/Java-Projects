/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package measurements;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Measurements {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        double length, width, bogus, bogus2;
        int bogus3 = 0;
        char restart;
        bogus = 1;
        bogus2 = 1;
        do
        {System.out.println("Welcome to the  measurement calculator.  Enter the length/width when the prompt asks.  Negative values are not allowed!");
        System.out.print("Length: ");
        length = doabarrelroll.nextDouble();
        System.out.print("Width: ");
        width = doabarrelroll.nextDouble();
         
        if ((length > 0)&&(width > 0))
        {for (bogus = 1; bogus <= width; bogus++)
        {System.out.println("");
        for (bogus2 = 1; bogus2 <= length; bogus2++)
        {System.out.print("*");}}}
        
        else
        {System.err.println("ERROR!  NO NEGATIVE VALUES CAN BE USED.");}
        
        System.out.println("");
        System.out.print("Would you like to go again: ");
        restart = doabarrelroll.next().charAt(0);}
        while ((restart == 'y')||(restart =='Y'));
        
        if ((restart == 'n')||(restart == 'N'))
        {System.out.println("BYE! (: ÷ D)");}
        
        else
        {do
            {System.err.println("YOU DIDN'T SAY THE MAGIC WORD!");}
        while (bogus3 == 0);}
    }
}