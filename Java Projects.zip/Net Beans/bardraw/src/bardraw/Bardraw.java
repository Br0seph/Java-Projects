/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bardraw;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Bardraw {

    /**
     * @param args the command line arguments
     */
     static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    static String red = "\u001B[31m";
     static String blue = "\u001B[34m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        int length;
        char type;
        String title;
        
        System.out.print("What is the title of the data: ");
        title = doabarrelroll.nextLine();
         do{
         System.out.print("Enter the number of data you have: ");
        length = doabarrelroll.nextInt();
        if (length > 0)
        {}
        else if (length <= 0)
        {System.err.println("ERROR.  NO NEGATIVE OR ZERO DATA VALUES");}
         else
        {length = 0;}}
        while(length <= 0);
       
        
        int number[] = new int [length], bogus;
        for (bogus = 0; bogus < number.length; bogus++)
        {number[bogus] = fillarray();}
        
        System.out.print("What symbol do you want to draw the lines with: ");
        type = doabarrelroll.next().charAt(0);
        
        System.out.println(green + title + black);
        for (bogus = 0; bogus < number.length; bogus++)
        {drawbar(number[bogus], type, bogus);}
    }
    
    public static int fillarray()
    {Scanner doabarrelroll = new Scanner (System.in);
    int number;
    
     do{
       System.out.print("Enter data: ");
        number = doabarrelroll.nextInt();
        if (number >= 0)
        {}
        else if (number < 0)
        {System.err.println("ERROR.  NO NEGATIVE DATA VALUES");}
      else
        {number = -1;}}
        while(number < 0);
    return(number);}
    
    public static void drawbar(int number, char type, int bogus)
    {int bogus2;
    System.out.print(blue + (bogus + 1) + black);
    System.out.print("|");
    for (bogus2 = 0; bogus2 < number; bogus2++)
    {System.out.print(type);}
    System.out.println();}
}