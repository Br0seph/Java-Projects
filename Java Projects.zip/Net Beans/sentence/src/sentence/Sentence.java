/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sentence;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Sentence {

    /**
     * @param args the command line arguments
     */
     public static String green = "\u001B[32m";
    public static String black = "\u001B[0m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        String sentance, answer;
        int wordnum = 0, bogus2 = 0;
        double  wordave1 = 0, wordave;
        
        do
        {System.out.print(green + "Type a sentance: " + black);
        sentance = doabarrelroll.nextLine();
        bogus2 = 0;
        wordnum = 0;
        wordave1 = 0;
        wordave = 0;
        
        for (String bogus: sentance.split(" "))//finds number of words in sentance
        {wordnum++;}
        
        System.out.print("There are ");
        System.out.print(wordnum);
        System.out.println(" words in the sentance.");//displays number of words
        
        String word[] = new String[wordnum];
        String longe, shorte;
        
        
        for (String bogus: sentance.split(" "))//writes each word to array of strings to find average # words
        {word[bogus2] = bogus.substring(0);
        wordave1 = (word[bogus2].length()) + (wordave1);
        bogus2++;}
        
        wordave = (wordave1)/(bogus2);
        System.out.print("The average number of letters is ");
        System.out.print(wordave);
        System.out.println(" letters.");//displays average letters
        
        longe = word[0];//finds longest word
        for(bogus2 = 0; bogus2 < word.length; bogus2++ )
        {if (word[bogus2].length() > longe.length())
        {longe = word[bogus2];}}
        
        System.out.print("'");//dispays longest word and its length
        System.out.print(longe);
        System.out.print("'");
        System.out.print(" is the longest word with ");
        System.out.print(longe.length());
        System.out.println(" letters.");
        
        shorte = word[0];//finds shortest word
        for(bogus2 = 0; bogus2 < word.length; bogus2++)
        {if (word[bogus2].length() < shorte.length())
        {shorte = word[bogus2];}}
        
        System.out.print("'");//dispays shortest word and its length
        System.out.print(shorte);
        System.out.print("'");
        System.out.print(" is the shortest word with ");
        System.out.print(shorte.length());
        System.out.println(" letters.");
       
        System.out.print(green + "Do you want to go again: " + black);
        answer = doabarrelroll.nextLine();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println(green + "Bye");
        System.out.println("(|:-D)" + black);}
        else if(answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("NOT VALID ANSWER");
        answer = "yes";}}
        while((answer.equals("yes"))||(answer.equals("Yes")));
    }
}
