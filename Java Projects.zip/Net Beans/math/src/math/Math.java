/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package math;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Math {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         Scanner j = new Scanner (System.in);
        
         System.out.print("First number: ");
         
         double a = j.nextDouble();
         
        System.out.println("Operations:");
        System.out.println("Press '1' to add");
        System.out.println("Press '2' to subtract");
        System.out.println("Press '3' to multiply");
        System.out.println("Press '4' to divide");
        
        int sign = j.nextInt();
      
        if (sign == 1)
        {System.out.print("Second number: ");
        double b = j.nextDouble();
        double c = a + b;
        System.out.println("Addition" + ": " + a + " + " + b + " = " + c);}
        
        if (sign == 2)
        {System.out.print("Second number: ");
        double b = j.nextDouble();
        double d = a - b;
        System.out.println("Subtraction" + ": " + a + " - " + b + " = " + d);}
    
        if (sign == 3)
        {System.out.print("Second number: ");
        double b = j.nextDouble();
        double e = a * b;
        System.out.println("Multiplication" + ": " + a + " × " + b + " = " + e);}
        
        if (sign == 4)
        {System.out.print("Second number: ");
        double b = j.nextDouble();
        double f = a / b;
        System.out.print("Division: ");
        System.out.println(a + " ÷ " + b + " = " + f);}
        
        else
        {System.out.println("You didn't say the magic number!");}
    }
}
