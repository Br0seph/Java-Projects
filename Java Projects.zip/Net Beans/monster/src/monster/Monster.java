/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monster;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Monster {
    
    //Characteristics
    String name;
    double height;
    String color;
    double weight;
    boolean friendliness;
    
    //Constructor
    public Monster(String name2, double height2, String color2, double weight2)
    {name = name2;
    height = height2;
    color = color2;
    weight = weight2;
    friendliness = true;}
    
    //Methods
    public void Roar()
    {System.out.println("RRROOOAAARRR!!!");}
    
    //setters/getters
    public void SetFriendliness(boolean friendliness2)
    {friendliness = friendliness2;}
    
    public double GetWeight()
    {return(weight);}
    
    public boolean GetFriendliness()
    {return(friendliness);}
}