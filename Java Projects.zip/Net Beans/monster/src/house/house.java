/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package house;

/**
 *
 * @author 193037
 */
import monster.Monster;
public class house {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Monster Broseph = new Monster ("Broseph", 666.0, "green", 69.0);
        
        Broseph.Roar();
        System.out.println(Broseph.GetWeight());
        System.out.println(Broseph.GetFriendliness());
        Broseph.SetFriendliness(false);
        System.out.println(Broseph.GetFriendliness());
    }
}