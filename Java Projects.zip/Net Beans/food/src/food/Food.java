/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package food;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Food {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("How many Hamburgers would you like to purchase ($5)?");
        System.out.println("How many french fries would you like to purchase (per container; $3)");
        System.out.println("Type in the number of items you want.  If you want none of that item, type 0.  Hit enter to separate numbers/continue");
        /*Variables*/
        Scanner a = new Scanner (System.in);
        int b = a.nextInt();
        int c = 5;
        int d = a.nextInt();
        int e = 3;
        int f = b * c;
        int g = d * e;
        int h = f + g;
        double i = h * 0.07;
        double j = i + h;
        /*Food Calculator*/
        System.out.print("Hamburgers: ");
        System.out.println(b);
        System.out.print("Fries: ");
        System.out.println(d);
        System.out.println("Price");
        System.out.print("Hamburgers: ");
        System.out.println(f);
        System.out.print("Fries: ");
        System.out.println(g);
        System.out.print("Subtotal: ");
        System.out.println(h + ".00");
        System.out.print("Tax: ");
        System.out.println(i + "0");
        System.out.print("Total: ");
        System.out.println(j + "0");
    }
}
