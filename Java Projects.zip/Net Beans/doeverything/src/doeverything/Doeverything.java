/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doeverything;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Doeverything {

    /**
     * @param args the command line arguments
     */
    static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    public static void main(String[] args) {
         Scanner doabarrelroll = new Scanner (System.in);
         Scanner scannert = new Scanner (System.in);
         String name, course, answer;
         double sem1, sem2, ave2, cave2, cave = 0;
         double percent = 0, percent2;
         char grade;
         int bogus, records;
         
         System.out.println(green + "Welcome.  To use this program enter  course and  the amount of students you have.  Then enter your students' names ");
         System.out.println("(first last). Then enter semester grades." + black);
         
         do{
         System.out.print("Course: ");
         course = doabarrelroll.nextLine();
         System.out.print("Amount of Students: ");
         records = doabarrelroll.nextInt();
         for (bogus = 0; bogus < records; bogus++)
         {System.out.print("Name: ");
         name = scannert.nextLine();
         
         System.out.print("Semester 1 Grade: ");
         sem1 = doabarrelroll.nextDouble();
         System.out.print("Semester 2 Grade: ");
         sem2 = doabarrelroll.nextDouble();
         ave2 = CalcAverage(sem1,sem2);
         grade = GradeConvert(ave2);
         PrintRecord(course, name, ave2, grade);
         cave = ClassAve(ave2, cave);
         percent = PercentFail(percent, ave2);}
         
         cave2 = cave/records;
         grade = GradeConvert(cave2);
         percent2 = (percent/records) * 100;
         System.out.println("|Class Average: " + cave2 + " " + grade + "|");
         System.out.println("|Percent of Fail: " + percent2 + "%");
         System.out.println("______________________________________________________________________________________________________________________");
         System.out.print("Do you want to enter more grades: ");
         answer = doabarrelroll.next();
         if (answer.equalsIgnoreCase("yes"))
         {}
         else if (answer.equalsIgnoreCase("no"))
         {System.out.println(green + "Bye");
         System.out.println("|:-D" + black);}
         else
         {System.err.println("ERROR.  " + answer + " IS NOT VALID ANSWER.");
         answer = "yes";}doabarrelroll.nextLine();}
         while (answer.equalsIgnoreCase("yes"));
    }
    
    public static double CalcAverage(double sem1, double sem2)
    {double ave;
    ave = ((sem1 + sem2))/2;
    return(ave);}
    
    public static char GradeConvert(double ave)
    {char grade; 
    if (ave >= 90)
    {grade = 'A';}
    else if ((ave < 90)&&(ave > 79))
    {grade = 'B';}
    else if ((ave < 80)&&(ave > 69))
    {grade = 'C';}
    else if ((ave < 70)&&(ave >= 65))
    {grade = 'D';}
    else
    {grade = 'F';}
    return(grade);}
    
    public static void PrintRecord(String course, String name, double ave, char grade)
    {int space;
    space = name.indexOf(" ");
    if ( space == -1)
    {System.out.println("______________________________________________________________________________________________________________________");
     System.out.println("|Student Name: " + name + "|");
     System.out.println("|Course: " + course + "|");
     System.out.println("|Grade: " + ave + " " + grade + "|");
     System.out.println("______________________________________________________________________________________________________________________");}
    else
    {System.out.println("______________________________________________________________________________________________________________________");
     System.out.println("|Student Name: " + name.substring(space) + ", " + name.substring(0,space) + "|");
     System.out.println("|Course: " + course + "|");
     System.out.println("|Grade: " + ave + " " + grade + "|");
     System.out.println("______________________________________________________________________________________________________________________");}
    }
    
    public static double ClassAve(double ave, double cave)
    {cave = cave + ave;
    return(cave);}
    
    public static double PercentFail(double percent, double ave)
    {if (ave < 65)
    {percent = percent + 1;}
    return(percent);}
}