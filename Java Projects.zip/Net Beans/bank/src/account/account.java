/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package account;

/**
 *
 * @author 193037
 */
public class account {
    
    public static double total = 0;
    String name;
    String an;
    double balance;
    String type;
    boolean overd;
    
    public account(String name2, String ann, double balance2, String type2)
    {name = name2;
    an = ann;
    balance = balance2;
    type = type2;}
    
    public int print(String ann, int bogus2)
    {if (ann.equals(an))
    {System.out.println("Name: " + name);
    System.out.println("Account #: " + an);
    System.out.println("Balance: $" + balance);
    System.out.println("Account Type: " + type);
    bogus2 = 6;}
    else
    {System.out.println("...SERCHING FOR ACCOUNT...");}
    return(bogus2);}
    
    public void deposit(double money)
    {if (money > 0)
    {balance = balance + money;
    total = total + money;
    System.out.println("You new account balance is $" + balance + ".");}
    else
     {System.err.println("ERROR!");}}
    
    public void withdrawSavings(double money)
    {if ((money > 0)&&(money < balance))
    {balance = balance - money;
    total = total - money;
    System.out.println("You new account balance is $" + balance + ".");}
    else
    {System.err.println("ERROR!");
    money = -1;}}
    
    public void withdrawChecking(double money)
    {if (money > 0)
    {balance = balance - money;
    total = total - money;}
    else if (money < balance)
    {balance = (balance - money) + 35;}
    else
    {System.err.println("ERROR!");
    money = -1;}
    System.out.println("You new account balance is $" + balance + ".");}
    
    public String over()
    {String over;
    if (balance < 0)
    {overd = true;
    over = "Over";}
    else
    {overd = false;
    over = "good";}
    return(over);}
    
    public void total()
    {System.out.println("The total amount of money in the bank is $" + total + ".");}
    
    public void balanceTotal()
    {System.out.println("The total balance for account " + name + " is $" + balance + ".");}
    
    public String getType()
    {return(type);}
    
    public void printnorm()
    {System.out.println("Name: " + name);
    System.out.println("Account #: " + an);
    System.out.println("Balance: $" + balance);
    System.out.println("Account Type: " + type);}
}