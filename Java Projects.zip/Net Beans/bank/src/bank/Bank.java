/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

/**
 *
 * @author 193037
 */
import account.account;
import java.util.*;
import java.io.*;
public class Bank {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {Scanner doabarrelroll = new Scanner (System.in);
        int bogus = 0;
        String choice;
    account ledger[] = startup();
    
    do{
    System.out.println("View");
    System.out.println("Deposit");
    System.out.println("Withdraw");
    System.out.println("Print 'Checking' accounts");
    System.out.println("Print 'Savings' accounts");
    System.out.println("check if account is 'Overdrawn'");
    System.out.println("Total");
    System.out.println("Close");
    
    
        choice = doabarrelroll.next();
    if (choice.equalsIgnoreCase("view"))
    {view(ledger);
    bogus = 100;}
    else if (choice.equalsIgnoreCase("deposit"))
    {deposit(ledger);
     bogus = 100;}
    else if (choice.equalsIgnoreCase("withdraw"))
    {withdraw(ledger);
     bogus = 100;}
    else if (choice.equalsIgnoreCase("checking"))
    {checking(ledger);
     bogus = 100;}
    else if (doabarrelroll.next().equalsIgnoreCase("savings"))
    {savings(ledger);
     bogus = 100;}
    else if (choice.equalsIgnoreCase("overdrawn"))
    {over(ledger);
     bogus = 100;}
    else if (choice.equalsIgnoreCase("total"))
    {ledger[0].total();
     bogus = 100;}
    else if (choice.equalsIgnoreCase("close"))
    {System.out.println("Bye!");
    bogus = 1;}
    else
    {System.err.println("ERROR.");}}
    while (bogus == 100);
    }//main loop
    
    public static account[] startup()
    {Scanner doabarrelroll = new Scanner (System.in);
    Random rand = new Random();
    int an, bogus;
    String ann, name, type;
    
    System.out.println("Enter the names of the 5 accounts in the bank.");
    System.out.print("First Account: ");
    name = doabarrelroll.nextLine();
    System.out.println("Enter type of account(optons are 'checking' and 'savings').");
    do{
        type = doabarrelroll.next();
    if ((type.equalsIgnoreCase("savings"))||(type.equalsIgnoreCase("checking")))
    {bogus = 1;}
    else
    {bogus = 0;
    System.err.println("ERROR.");}}
    while (bogus == 0);
    an = rand.nextInt(10000);
    if (an < 10)
    {ann = "000" + an;}
    else if ((an < 100)&&(an > 9))
    {ann = "00" + an;}
    else if ((an < 1000)&&(an > 99))
    {ann = "0" + an;}
    else
    {ann = "" + an;}
    account a1 = new account (name, ann, 0, type);
    System.out.println("Account # is " + ann);
    
    System.out.print("Second Account: ");doabarrelroll.next();
    name = doabarrelroll.nextLine();
    System.out.println("Enter type of account(optons are 'checking' and 'savings').");
    do{
        type = doabarrelroll.next();
    if ((type.equalsIgnoreCase("savings"))||(type.equalsIgnoreCase("checking")))
    {bogus = 1;}
    else
    {bogus = 0;
    System.err.println("ERROR.");}}
    while (bogus == 0);
    an = rand.nextInt(10000);
    if (an < 10)
    {ann = "000" + an;}
    else if ((an < 100)&&(an > 9))
    {ann = "00" + an;}
    else if ((an < 1000)&&(an > 99))
    {ann = "0" + an;}
    else
    {ann = "" + an;}
    account a2 = new account (name, ann, 0, type);
    System.out.println("Account # is " + ann);
    
    System.out.print("Third Account: ");doabarrelroll.next();
    name = doabarrelroll.nextLine();
    System.out.println("Enter type of account(optons are 'checking' and 'savings').");
    do{
        type = doabarrelroll.next();
    if ((type.equalsIgnoreCase("savings"))||(type.equalsIgnoreCase("checking")))
    {bogus = 1;}
    else
    {bogus = 0;
    System.err.println("ERROR.");}}
    while (bogus == 0);
    an = rand.nextInt(10000);
    if (an < 10)
    {ann = "000" + an;}
    else if ((an < 100)&&(an > 9))
    {ann = "00" + an;}
    else if ((an < 1000)&&(an > 99))
    {ann = "0" + an;}
    else
    {ann = "" + an;}
    account a3 = new account (name, ann, 0, type);
    System.out.println("Account # is " + ann);
    
    System.out.print("Fourth Account: ");doabarrelroll.next();
    name = doabarrelroll.nextLine();
    System.out.println("Enter type of account(optons are 'checking' and 'savings').");
    do{
        type = doabarrelroll.next();
    if ((type.equalsIgnoreCase("savings"))||(type.equalsIgnoreCase("checking")))
    {bogus = 1;}
    else
    {bogus = 0;
    System.err.println("ERROR.");}}
    while (bogus == 0);
    an = rand.nextInt(10000);
    if (an < 10)
    {ann = "000" + an;}
    else if ((an < 100)&&(an > 9))
    {ann = "00" + an;}
    else if ((an < 1000)&&(an > 99))
    {ann = "0" + an;}
    else
    {ann = "" + an;}
    account a4 = new account (name, ann, 0, type);
    System.out.println("Account # is " + ann);
    
    System.out.print("Fifth Account: ");doabarrelroll.next();
    name = doabarrelroll.nextLine();
    System.out.println("Enter type of account(optons are 'checking' and 'savings').");
    do{
        type = doabarrelroll.next();
    if ((type.equalsIgnoreCase("savings"))||(type.equalsIgnoreCase("checking")))
    {bogus = 1;}
    else
    {bogus = 0;
    System.err.println("ERROR.");}}
    while (bogus == 0);
    an = rand.nextInt(10000);
    if (an < 10)
    {ann = "000" + an;}
    else if ((an < 100)&&(an > 9))
    {ann = "00" + an;}
    else if ((an < 1000)&&(an > 99))
    {ann = "0" + an;}
    else
    {ann = "" + an;}
    account a5 = new account (name, ann, 0, type);
    System.out.println("Account # is " + ann);
    
    account ledger[] = {a1, a2, a3, a4, a5};
    return(ledger);}//cuz every little thing is gonna be alright!
    
    public static void view(account[] ledger)
    {Scanner doabarrelroll = new Scanner (System.in);
    String ann;
    int bogus, bogus2 = 0, bogus3;
    
    do{
    System.out.println("Type account # to proceed.");
    ann = doabarrelroll.next();
    for(bogus = 0; bogus < 5; bogus++)
    {bogus = ledger[bogus].print(ann, bogus);}
    
    if (bogus == 5)
    {System.err.println("ERROR.  ACCOUNT NOT FOUND.");
    bogus3 = 1;}
    else
    {bogus3 = 0;}}
    while(bogus3 == 1);}//view account by asking for a#
    
    public static void deposit(account[] ledger)
    {Scanner doabarrelroll = new Scanner (System.in);
    double money, balance;
    String ann;
    int bogus, bogus2 = 0, bogus3;
    
    do{
    System.out.println("Type account # to proceed.");
    ann = doabarrelroll.next();
    for(bogus = 0; bogus < 5; bogus++)
    {bogus = ledger[bogus2].print(ann, bogus);
    bogus2++;}
    
    if (bogus == 5)
    {System.err.println("ERROR.  ACCOUNT NOT FOUND.");
    bogus3 = 1;}
    else
    {bogus3 = 0;}}
    while(bogus3 == 1);
    
    do{
    System.out.println("Enter diposit.");
    money = doabarrelroll.nextDouble();
    ledger[bogus2 - 1].deposit(money);}
    while(money < 0);}//deposits money for any account
    
    public static void withdraw(account[] ledger)
    {Scanner doabarrelroll = new Scanner (System.in);
    String ann, type;
    int bogus, bogus2 = 0, bogus3;
    double money;
    
    do{
    System.out.println("Type account # to proceed.");
    ann = doabarrelroll.next();
    for(bogus = 0; bogus < 5; bogus++)
    {bogus = ledger[bogus].print(ann, bogus);
    bogus2++;}
    
    if (bogus == 5)
    {System.err.println("ERROR.  ACCOUNT NOT FOUND.");
    bogus3 = 1;}
    else
    {bogus3 = 0;}}
    while(bogus3 == 1);
    bogus2 = bogus2 - 1;
    type = ledger[bogus2].getType();
    
    if (type.equalsIgnoreCase("savings"))
    {do{
    System.out.println("Enter Withdrawl.");
    money = doabarrelroll.nextDouble();
    ledger[bogus2].withdrawSavings(money);}
    while(money < 0);}
    else
    {do{
    System.out.println("Enter Withdrawl.");
    money = doabarrelroll.nextDouble();
    ledger[bogus2].withdrawChecking(money);}
    while(money < 0);}}//withdraws money for any account
    
    public static void checking(account[] ledger)
    {Scanner doabarrelroll = new Scanner (System.in);
    String type;
    int bogus;
    
    for (bogus = 0; bogus < 5; bogus++)
    {type = ledger[bogus].getType();
    if (type.equalsIgnoreCase("checking"))
    {ledger[bogus].printnorm();}}}//views all checking accounts
    
    public static void savings(account[] ledger)
    {Scanner doabarrelroll = new Scanner (System.in);
    String type;
    int bogus;
    
    for (bogus = 0; bogus < 5; bogus++)
    {type = ledger[bogus].getType();
    if (type.equalsIgnoreCase("savings"))
    {ledger[bogus].printnorm();}}}//views all savings accounts
    
    public static void over(account[] ledger)
    {String over;
    int bogus;
    
    System.out.println("Here are the overdrawn accounts in the bank");
    for (bogus = 0; bogus < 5; bogus++)
    {over = ledger[bogus].getType();
    if (over.equalsIgnoreCase("over"))
    {ledger[bogus].printnorm();}}}//views any overdrawn account
}