/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

import java.util.Scanner;


public class JavaApplication25 {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    String input = in.next();
    if(input.length() != 10) {
      System.out.println("LOL no");
      System.exit(0);
    }
    String changed = change(input);
    if(changed.equals("fvbl}bf334")) {
      System.out.println("Awesome!");
      System.out.println("The flag is: " + input);
    } else {
      System.out.println("LOL no");
    }
   }
   private static String change(String s) {
    char[] temp = new char[10];
    for(int i = 0; i < s.length(); i++) {
      temp[i] = (char)(s.charAt(i) + 3);
    }
    return new String(temp);
  }
}
