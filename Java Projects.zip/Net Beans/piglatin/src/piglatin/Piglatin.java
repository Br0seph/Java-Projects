/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piglatin;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Piglatin {

    /**
     * @param args the command line arguments
     */
    public static String green = "\u001B[32m";
    public static String black = "\u001B[0m";
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        String sentance, answer;
        int length;
        
        do{
        System.out.print(green + "Enter a sentance: " + black);
        sentance = doabarrelroll.nextLine();
        
        for (String bogus: sentance.split(" "))
        {System.out.print(bogus.substring(1));
        System.out.print(bogus.charAt(0));
        System.out.print("a");
        System.out.print(" ");}
        System.out.println("");
        
        System.out.print(green + "Do you want to go again: " + black);
        answer = doabarrelroll.nextLine();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println(green + "Bye");
        System.out.println("(|:-D)" + black);}
        else if (answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("NOT VALID ANSWER");
        answer = "yes";}}
        while((answer.equals("yes"))||(answer.equals("Yes")));
    }
}
