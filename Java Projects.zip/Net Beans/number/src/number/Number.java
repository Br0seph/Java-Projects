/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package number;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Number {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner doabarrelroll = new Scanner (System.in);
    double num = 0;
    char a;
    double factor2, factor, factor3, num2;
    do
    {System.out.print("What is the minimum number to go to: ");
    factor3 = doabarrelroll.nextDouble();
    
    System.out.print("What is the maximum number to go to: ");
    factor2 = doabarrelroll.nextDouble();
    
    System.out.print("Enter the factor to add by: ");
    factor = doabarrelroll.nextDouble();
    
    if (factor3 < factor2)
    {for (num = 0; factor3 <= factor2; factor3 = factor3 + factor)
    {System.out.println(factor3);}}
    
    else
    {System.out.println("ERROR");}
    
    System.out.print("Would you like to go again: ");
    a = doabarrelroll.next().charAt(0);}
    while (a == 'y');
    }
}
