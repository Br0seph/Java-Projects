/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loop_of_4s;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Loop_of_4s {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        int bar;
        
        System.out.print("Enter bar length: ");
        bar = doabarrelroll.nextInt();
        drawbar(bar);
    }
 
    public static void drawbar(int bar)
    {for (int bogus = 0; bogus < bar; bogus++)
    {System.out.print("*");}
    System.out.println();}
}
