/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Grades {

    /**
     * @param args the command line arguments
     */
    public static final String GREEN = "\u001B[32m";//\u001B[#m determines color of text.  there are 36 options not including 0 which is default color
    public static final String DEFAULT = "\u001B[0m";
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        String err = "\u001B[31m ERROR.";//adding color code to normal sring will change color and not display code
        String cc = "CANNOT COMPUTE. \u001B[0m";
        String nerr = " IS NOT A REGISTERED STUDENT. \u001B[0m";
        String update = "\u001B[32m GRADES UPDATED. \u001B[0m";
        int studentnum, bogus, bogus2, bogus3;
        String option, math, studentname;
        int mathtest = -1;
        int mathquiz = -1;
        int mathhw = -1;
        String input = "GRADE AREADY INPUT FOR THIS FILE. \u001B[0m";
        
        System.out.print(GREEN + "AMOUNT OF STUDENTS: " + DEFAULT);
        studentnum = doabarrelroll.nextInt();
        String name[] = new String[studentnum];
        String Lname[] = new String[studentnum];
        double grade[] = new double[studentnum];
        double mgrade[] = new double[studentnum];
        
        bogus = 0;
        System.out.println(GREEN + "ENTER FULL NAMES." + DEFAULT);
        for (bogus = 0; bogus < name.length; bogus++)
        {bogus2 = bogus + 1;
        System.out.print("First name " + bogus2 + ": ");
        name[bogus] = doabarrelroll.next();
        System.out.print("Last name " + bogus2 + ": ");
        Lname[bogus] = doabarrelroll.next();}
        
        System.out.println("These are the names you entered.  They are formatted 'Last, First'.");
         for (bogus = 0; bogus < name.length; bogus++)
        {System.out.println(Lname[bogus] + ", " + name[bogus]);}
         
         System.out.print("What would you like to do (actions are  view, math, english, science, and history): ");
         option = doabarrelroll.next();
        
         
         if ((option == "view")||(option == "View"))
         {for (bogus = 0; bogus < Lname.length; bogus++)
         {System.out.print(Lname[bogus]);
         System.out.print(", " + name[bogus]);
         System.out.print(": " + grade[bogus]);}}
         
         else if ((option.equals("math"))||(option.equals("Math")))
         { System.out.print("What student do you want to grade (type last name): ");
         studentname = doabarrelroll.next();
         do
         {System.out.print("What type of assignment do you want to enter (test, quiz, homework): ");
         math = doabarrelroll.next();
         if((math.equals("test"))||(math.equals("Test")))
         {if (mathtest == -1)
         {for (bogus = 0; bogus < Lname.length; bogus++)
         {if (Lname[bogus].equals(studentname))
         {System.out.print("Type the grade (out of 100 points) for " + studentname + " recieved: ");
         mathtest = doabarrelroll.nextInt();}
         else
         {System.out.println(err + studentname + nerr);
         bogus = Lname.length;}}}
         else
         {System.out.println(err + input);}}
         if ((math.equals("quiz"))||(math.equals("Quiz")))
         {if (mathquiz > -1)
         {for (bogus = 0; bogus < Lname.length; bogus++)
         {if (Lname[bogus] == studentname)
         {System.out.print("Type the grade (out of 100 points) for" + studentname + " recieved: ");
         mathquiz = doabarrelroll.nextInt();}
         else
         {System.out.println(err + nerr);
         bogus = Lname.length;}}}
         else
         {System.out.println(err + input);}}
         if ((math.equals("Homework"))||(math.equals("homework")))
         {if (mathhw > -1)
         {for (bogus = 0; bogus < Lname.length; bogus++)
         {if (Lname[bogus] == studentname)
         {System.out.print("Type the grade (out of 100 points) for" + studentname + " recieved: ");
         mathhw = doabarrelroll.nextInt();}
         else
         {System.out.println(err + nerr);
         bogus = Lname.length;}}}
         else
         {System.out.println(err + input);}}}
         while((mathtest == -1)&&(mathquiz == -1)&&(mathhw == -1));
         System.out.print(Lname[bogus] + ", " + name[bogus] + "'s final math grade is");
         mgrade[bogus] = ((2*mathtest)+ (mathquiz) + (.2 * mathhw))/3;}
    }
}
