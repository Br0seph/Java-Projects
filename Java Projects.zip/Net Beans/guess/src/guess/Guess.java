/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guess;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Guess {

    /**
     * @param args the command line arguments
     */
       static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    static String red = "\u001B[31m";
    static String blue = "\u001B[34m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        Random idk = new Random();
        String answer, answer3;
        double money, bet = 0;
        int number, guess = 0, bogus, bogus2, win = 0, game;
        
         do{
        System.out.print("How much money do you have: ");
        money = doabarrelroll.nextDouble();
        if (money > 0)
        { System.out.println("You walked in with " + green + "$" + money + black + ".");}
        else if (money <= 0)
        {System.err.println("ERROR.  NO NEGATIVE OR ZERO MONEY VALUES");}
        else
        {}}
        while(money <= 0);
        System.out.println("Welcome to the guessing game.  The computer is ready to pick a number.");
        
        for (bogus2 = 0; bogus2 < 10; bogus2++)
        {
            game = bogus2 + 1;
            System.out.println("You are on game " + blue + game + black + ".");
            System.out.println("You have " + green + "$" + money + "." + black);do{
                System.out.print("How much money do you want to bet: ");
            bet = doabarrelroll.nextDouble();
            if(bet > money)
            {System.err.println("ERROR.  $" + bet + " IS TOO MUCH MONEY.");
            answer3 = "notgood";}
            else if (bet <= 0)
            {answer3 = "notgood";
            System.err.println("ERROR.  NO NEGATIVE OR ZERO DOLLAR BETS.");}
            else
            {answer3 = "good";}}
            while (answer3.equalsIgnoreCase("notgood"));
        do{
        System.out.print("Are you ready: ");
        answer = doabarrelroll.next();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println("Okay!");}
        else if (answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("ERROR.  " + answer + " IS NOT VALID ANSWER");
        answer = "no";}}
        while (answer.equalsIgnoreCase("no"));
        
        number = idk.nextInt(10) + 1;
        //System.out.println(number);
        
        System.out.println("The computer picked a number in between 1 and 10.  Take a guess");
        for (bogus = 0; bogus < 3; bogus++)
        {guess = doabarrelroll.nextInt();
         if ((guess > 10)||(guess < 1))
        {System.err.println("ERROR.  ONLY VALUES IN BETWEEN 1 AND 10 ARE ALLOWED.");
        guess = 0;}
        else if (guess == number)
        {bogus = 100;
        guess = number;}
        else if (guess < number)
        {System.out.println(red + "Higher!" + black);
        guess = 0;}
        else if (guess > number)
        {System.out.println(red + "Lower!" + black);
        guess = 0;}}
        
        if (number == guess)
        {System.out.println("You win " + green + "$" + bet + black + ".");
        money = money + bet;
        win = win + 1;}
        else 
        {System.out.println("You lose " + red + "$" + bet + black + ".");
        money = money - bet;}
        
        if (money < 1)
        {bogus2 = 100;}}
        
         if (money < 1)
        {System.out.println(red + "You ran out of money!" + black);}
         
         System.out.println("You won " + win + " games.");
        
        if ((win <= 7)&&(win > 2))
        {System.out.println("You are an " + green + "amateur" + black + " at this game.");}
        else if (win == 8)
        {System.out.println("You are an " + green + "advanced" + black + "player!  Keep trying.");}
        else if (win == 9)
        {System.out.println("You are now a certified " + green + "professional" + black + ".  Your doing great!");}
        else if (win == 10)
        {System.out.println("Stop " + red + "hacking " + black + "the game.  " + red + "You lose!" + black);}
        else 
        {System.out.println(red + "You lose!" + black);}
    }
    
}
