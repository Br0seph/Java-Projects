/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ss;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Ss {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner doabarrelroll = new Scanner (System.in);
        String name, ss;
        int index, bogus;
        
            bogus = 0;
        System.out.print("Enter full name: ");
        name = doabarrelroll.nextLine();
        System.out.print("Enter Social Security # (no spaces): ");
        ss  = doabarrelroll.next();
        index = name.indexOf(" ");
        
        if (ss.length() == 9)
        {System.out.print(name.substring(0,1));
        System.out.print(".  ");
        System.out.println(name.substring(index + 1));
        System.out.print("XXX-XX-");
        System.out.println(ss.substring(5));
        bogus = 1;}
        
        else
        {System.err.println(ss + " IS NOT VALID NUMBER");}
    }
}
