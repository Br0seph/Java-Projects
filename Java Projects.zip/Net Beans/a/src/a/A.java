/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*This program should
        
        *Allow you to type three integers
        *Calculate the sum/average/product/smallest/largest from the inputed integers
        *Created by Joey Yannuzzi.  Last edited 2/15/17.
        */
        
        //Startup
         Scanner a = new Scanner (System.in);
         System.out.println("Welcome to the integer calculator.  Put in three integers (no decimals/fractions) when the promt asks.");
         System.out.print("Integer 1: ");
         
         //first integer input
         int int1 = a.nextInt();
         
         //Second integer prompt
         System.out.print("Integer 2: ");
         
         //Second integer input
         int int2 = a.nextInt();
         
         //Third integer pronpt
         System.out.print("Integer 3: ");
         
         //Third integer input
         int int3 = a.nextInt();
         
         //Sum
         System.out.print("Sum: ");
         int sum = int1 + int2 + int3;
         System.out.println(sum);
         
         //Average
         System.out.print("Average: ");
         int average = sum / 3;
         System.out.println(average);
         
         //Product
         System.out.print("Prodict: ");
         int product = int1 * int2 * int3;
         System.out.println(product);
         
         //Smallest
         System.out.print("Smallest: ");
         if ((int1 < int2)&&(int1 < int3))
         {System.out.println(int1);}
         if ((int2 < int1)&&(int2 < int1))
         {System.out.println(int2);}
         if ((int3 < int1)&&(int3 < int2))
         {System.out.println(int3);}
         
         //Largest
         System.out.print("Largest: ");
         if ((int1 > int2)&&(int1 > int3))
         {System.out.println(int1);}
         if ((int2 > int1)&&(int2 > int3))
         {System.out.println(int2);}
         if ((int3 > int1)&&(int3 > int2))
         {System.out.println(int3);}
         
         /*This is the end*/
    }
}
