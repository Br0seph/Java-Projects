/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author 193037
 */
import java.util.Scanner;
public class Example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        Scanner doabarrelroll = new Scanner (System.in);
        String choice;
        String answer;
        double yes,i1,i2;
        
        do
        {System.out.print("Do you want to convert dollars or pounds: ");
        choice = doabarrelroll.next();
        
        if (choice.equalsIgnoreCase("dollars"))
        {yes=dollarstopounds(i1,i2);}// function call
        
        else if (choice.equalsIgnoreCase("pounds"))
        {ptd();}
        
        else
        {System.err.print(choice);
        System.err.println(" IS NOT RESGISTERED RESPONSE.");}
        
     System.out.print("Do you want to go again: ");
        answer = doabarrelroll.next();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println("Bye");
        System.out.println("(|:-D)");}
        else if(answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("NOT VALID ANSWER");
        answer = "yes";}}
        while((answer.equals("yes"))||(answer.equals("Yes")));
      
    }
    
    //function definition
    public static void dollarstopounds(double dollars)
    {
        
     
        double pounds;
       
        pounds=dollars*.78;
        System.out.println(dollars + "$ = "+ pounds +" pounds");
    }
    
    public static void ptd()
    {Scanner doabarrelroll = new Scanner (System.in);
    double dollars, pounds;
    
    pounds = doabarrelroll.nextDouble();
    dollars = pounds * 1.28;
    
    System.out.println(pounds + " pounds = $ " + dollars);}
}
