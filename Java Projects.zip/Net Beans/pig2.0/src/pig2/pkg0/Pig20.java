/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pig2.pkg0;

/**
 *
 * @author 193037
 */
import java.util.*;
public class Pig20 {

    /**
     * @param args the command line arguments
     */
     static String green = "\u001B[32m";
    static String black = "\u001B[0m";
    static String red = "\u001B[31m";
     static String blue = "\u001B[34m";
    public static void main(String[] args) {
        Scanner doabarrelroll = new Scanner (System.in);
        Random rand = new Random();
        String answer, answer2, answer3, answer4;
        int bogus, dice, cpu = 0, playert = 0, player = 0;
        
        System.out.println("Welcome to pig.  Reach 100pts first to win!  The twist is if you roll a 1, you loose ALL your points scored in that round!");  
        System.out.println(red + "Warning this game is REALLY HARD!!!" + black);
        
        System.out.println("The computer is ready to roll the die.");
        do{
        System.out.print("Are you ready: ");
        answer = doabarrelroll.next();
        if (answer.equalsIgnoreCase("no"))
        {System.out.println("Okay!");}
        else if (answer.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("ERROR.  " + answer + " IS NOT VALID ANSWER");
        answer = "no";}}
        while (answer.equalsIgnoreCase("no"));
        
        while((cpu < 100)&&(player < 100))
        {dice = 0;
        playert = 0;
        System.out.println("The computer rolled:");
        for (bogus = 0; bogus < 3; bogus++)
        {dice = rand.nextInt(6) + 1;
        System.out.println(blue + dice + black);
        cpu = cpu + dice;}
        System.out.println("The computer's score is " + blue + cpu + black + ".");
        if ((cpu < 100)&&(player < 100))
        
        {
        
        System.out.print("It is you turn.  ");
        do{
         do{
        System.out.print("Are you ready: ");
        answer2 = doabarrelroll.next();
        if (answer2.equalsIgnoreCase("no"))
        {System.out.println("Okay!");}
        else if (answer2.equalsIgnoreCase("yes"))
        {}
        else
        {System.err.println("ERROR.  " + answer2 + " IS NOT VALID ANSWER");
        answer2 = "no";}}
        while (answer2.equalsIgnoreCase("no"));
         
         System.out.println("You rolled the dice.");
         System.out.println("You rolled a");
         dice = rand.nextInt(6) + 1;
         System.out.println(green + dice + black);
         if (dice == 1)
         {System.out.println(red + "Better luck next time." + black);
         answer4 = "no";
         playert = 0;
         System.out.println("Your score is " + green + (player) + black + ".");}
         
         else
         {playert = playert + dice;
         System.out.println("Your score is " + green + (player + playert) + black + ".");
             do{
        System.out.print("Do you want to roll again: ");
        answer3 = doabarrelroll.next();
        if (answer3.equalsIgnoreCase("yes"))
        {System.out.println("Okay!");
        answer4 = "yes";
        answer3 = "sure";}
        else if (answer3.equalsIgnoreCase("no"))
        {answer4 = "no";
        answer3 = "no";}
        else
        {System.err.println("ERROR.  " + answer3 + " IS NOT VALID ANSWER");
        answer3 = "yes";
        answer4 = "";}}
        while (answer3.equalsIgnoreCase("yes"));}}
        while(answer4.equalsIgnoreCase("yes"));
        player = player + playert;}}
        
        
        if (player >= 100)
        {System.out.println(green + "You win!!!" + black);}
        else if (cpu >= 100)
        {System.out.println(blue + "The computer wins!" + black);}
        else
        {System.out.println(red + "You both lose!" + black);}
    }
    
}
